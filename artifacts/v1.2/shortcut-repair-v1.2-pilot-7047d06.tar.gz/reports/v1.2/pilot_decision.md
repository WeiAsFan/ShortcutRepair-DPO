# v1.2 Pilot 选择

选定候选：`None`。没有满足能力保持条件的 DPO 路径；不打开 test，也不强行选择 SFT。

| 候选 | 保留条件 | score fresh response | score nuisance | 阶段数 |
|---|---|---:|---:|---:|
| direct_dpo | 未通过 | 0.8906 | 0.8750 | 1 |
| score_sft | 未通过 | 0.0000 | 1.0000 | 1 |
| sft_dpo | 未通过 | 0.9844 | 1.0000 | 2 |
| direct_dpo_lr_half | 未通过 | 0.0000 | 1.0000 | 1 |
| sft_dpo_lr_half | 未通过 | 0.9844 | 0.9922 | 2 |

仅使用 seed 42 和 dev；没有读取正式 test。
是否使用唯一补充轮（DPO 学习率减半、最多两次）：True。
SFT 为能力基线；即使优于 DPO，也不把 SFT 改称为 DPO。
